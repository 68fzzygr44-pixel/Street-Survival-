# Street Survival — multiplayer

A small real-time 2-player browser game. Players can join from separate devices using the same hosted URL and a 5-character room code.

## Run locally
1. Install Node.js 18+.
2. In this folder run:
   npm install
   npm start
3. Open http://localhost:3000

## Put it online
Use a Node-capable host such as Render, Railway, Fly.io, or another service that supports long-lived WebSocket connections.
- Build command: `npm install`
- Start command: `npm start`
- No database is required for this version.
- Share the deployed HTTPS URL with your second player.
- Player 1 creates a room; Player 2 enters the room code.

## Rules
Reach $5,000 or reduce the opponent to 0 health. Each round, both players choose one action. The server resolves both choices and broadcasts the new state to both devices.

## Important
The server owns the game state. The browser does not decide the opponent's state, so the two devices stay synchronized through WebSockets.
